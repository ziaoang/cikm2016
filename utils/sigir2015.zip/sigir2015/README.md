# SIGIR 2015

SIGIR is the major international forum for the presentation of new research results and for the demonstration of new systems and techniques in the broad field of information retrieval (IR). The Conference and Program Chairs invite all those working in areas related to IR to submit original papers for review. SIGIR 2015 welcomes contributions related to any aspect of IR theory and foundation, techniques, and applications. Relevant topics include, but are not limited to:

* Document Representation and Content Analysis (text representation, document structure, linguistic analysis, NLP for IR, cross- and multi-lingual IR, information extraction, sentiment analysis, clustering, classification, topic models, facets, text streams)
* Queries and Query Analysis (query intent, query suggestion and prediction, query representation and reformulation, query log analysis, conversational search and dialogue, spoken queries, summarization, question answering)
* Retrieval Models and Ranking (IR theory, language models, probabilistic retrieval models, learning to rank, combining searches, diversity and aggregated search)
* Search Engine Architectures and Scalability (indexing, compression, distributed IR, P2P IR, mobile IR, cloud IR)
* Users and Interactive IR (user studies, user and task models, interaction analysis, session analysis, exploratory search, personalized search, social and collaborative search, search interface, whole session support)
* Filtering and Recommending (content-based filtering, collaborative filtering, recommender systems)
* Evaluation (test collections, experimental design, effectiveness measures, session-based evaluation, simulation)
* Web IR and Social Media Search (link analysis, click models/behavioral modeling, social tagging, social network analysis, blog and microblog search, forum search, community-based QA, adversarial IR and spam, vertical and local search)
* IR and Structured Data (XML search, ranking in databases, desktop search, entity search)
* Multimedia IR (image search, video search, speech/audio search, music search)
* Search applied to the Internet of Things (billions of devices, sensors, and actuators are now connected to the Web, which will affect how people search and browse the Web)
* Other Applications (digital libraries, enterprise search, genomics IR, legal IR, patent search, text reuse, new retrieval problems)
