eta = [0 0.1 0.2 0.3 0.4 0.5 0.6];
%qe p30
p5 =            [ 
0.5389
0.5389
0.5611
0.5778
0.5778
0.5667
0.5389
 ];
p5_baseline =   [0.5389 0.5389 0.5389 0.5389 0.5389 0.5389 0.5389];

p30 = [
0.3880
0.3944
0.3926
0.4056
0.4056
0.4102
0.4037
  ];
p30_baseline =   [0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880];
map =            [ 
0.3865
0.3946
0.4033
0.4103
0.4065
0.4010
0.3770
 ];
map_baseline =   [0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865];


figure(1);
plot(eta,p5,'r-o',eta,p5_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('P@5');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6'});
xlim([0 0.6])


figure(2);
plot(eta,p30,'r-o',eta,p30_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6'});
xlim([0 0.6])


figure(3);
plot(eta,map,'r-o',eta,map_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6'});
xlim([0 0.6])
