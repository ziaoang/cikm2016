eta = [30 50 100 300 500];
%qe p30
p5 =            [ 
0.5389
0.5611
0.5778
0.5772
0.5611
 ];
p5_baseline =   [0.5389 0.5389 0.5389 0.5389 0.5389];

p30 = [
0.4037
0.4037
0.4056
0.4083
0.4037
  ];
p30_baseline =   [0.3880 0.3880 0.3880 0.3880 0.3880];
map =            [ 
0.4013
0.4040
0.4065
0.4070
0.3976
 ];
map_baseline =   [0.3865 0.3865 0.3865 0.3865 0.3865];


figure(1);
plot(eta,p5,'r-o',eta,p5_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('# feedback documents');
ylabel('P@5');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])


figure(2);
plot(eta,p30,'r-o',eta,p30_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('# feedback documents');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])


figure(3);
plot(eta,map,'r-o',eta,map_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('# feedback documents');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])
