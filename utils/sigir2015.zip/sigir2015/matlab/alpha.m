eta = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
%qe p30
p10 =            [ 
0.4889
0.4972
0.5
0.5056
0.5139
0.5111
0.5167
0.525
0.5083
0.5028
0.4972
 ];
p10_2s = [
    0.5278
0.525
0.5333
0.5389
0.5417
0.5528
0.5556
0.5556
0.5583
0.5333
0.5306
];
p10_baseline =   [0.4889 0.4889 0.4889 0.4889 0.4889 0.4889 0.4889 0.4889 0.4889 0.4889 0.4889];

p30 = [
0.388
0.3907
0.3926
0.4056
0.4056
0.412
0.4139
0.4157
0.413
0.413
0.4157
  ];
p30_2s=[
    0.4269
0.4306
0.4361
0.4398
0.4417
0.4417
0.4426
0.4343
0.4352
0.4194
0.4204
];
p30_baseline =   [0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880 0.3880];

map =            [ 
0.3865
0.3904
0.3953
0.4003
0.4036
0.4072
0.4112
0.4004
0.3969
0.3941
0.3881
 ];
map_baseline =   [0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865 0.3865];
map_2s = [
    0.4041
0.4038
0.4094
0.4106
0.411
0.4122
0.4127
0.4079
0.4078
0.385
0.382
];


figure(1);
plot(eta, p10_2s, 'g-^', eta,p10,'r-o', eta,p10_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM', 'SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('P@10');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1'});
xlim([0 1])
ylim([0.48 0.62])


figure(2);
plot(eta, p30_2s,'g-^', eta,p30,'r-o',  eta, p30_baseline,'b-.');
legend('QEFEM + SMM','QEFEM',  'SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1'});
xlim([0 1])
ylim([0.38 0.475])

figure(3);
plot(eta, map_2s,'g-^', eta,map,'r-o',  eta, map_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM', 'SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1]);
set(gca,'xticklabel',{ '0', '0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1'});
xlim([0 1])
ylim([0.38 0.435])
