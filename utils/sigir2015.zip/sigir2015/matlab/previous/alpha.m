eta = [0 0.1 0.3 0.5  0.7  0.9];
%qe p30
p30 = [
0.3914 
0.3935 
0.4022 
0.3978 
0.3742 
0.3032 
  ];
p30_baseline =   [0.3914 0.3914 0.3914 0.3914 0.3914 0.3914];
map =            [ 
0.3731 
0.3780 
0.3840 
0.3662 
0.3220 
0.2699    
 ];
map_baseline =   [0.3731 0.3731 0.3731 0.3731 0.3731 0.3731];

figure(1);
plot(eta,p30,'r-o',eta,p30_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.3  0.5  0.7  0.9]);
set(gca,'xticklabel',{'0', '0.1','0.3','0.5','0.7','0.9'});
xlim([0 1])


figure(2);
plot(eta,map,'r-o',eta,map_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\alpha');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0, 0.1 0.3  0.5  0.7  0.9]);
set(gca,'xticklabel',{'0', '0.1','0.3','0.5','0.7','0.9'});
xlim([0 1])
