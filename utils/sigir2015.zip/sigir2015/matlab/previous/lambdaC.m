eta = [0.1 0.3 0.5  0.7  0.9 1];
%qe p30
p30 = [
0.4032 
0.4032 
0.4032 
0.4022 
0.4032 
0.3989  ];
p30_baseline =   [0.3914 0.3914 0.3914 0.3914 0.3914 0.3914  ];
map =            [
0.3848 
0.3842 
0.3841 
0.3842 
0.3846 
0.3848  
 ];
map_baseline =   [0.3731 0.3731 0.3731 0.3731 0.3731 0.3731 ];

figure(1);
plot(eta,p30,'r-o',eta,p30_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\lambda_C');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0 0.1 0.3  0.5  0.7  0.9]);
set(gca,'xticklabel',{'0', '0.1','0.3','0.5','0.7','0.9'});
xlim([0 0.9])


figure(2);
plot(eta,map,'r-o',eta,map_baseline,'b-.');
legend('QEETM','SimpleKL', 'location','northeast');
xlabel('\lambda_C');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0, 0.1 0.3  0.5  0.7  0.9]);
set(gca,'xticklabel',{'0', '0.1','0.3','0.5','0.7','0.9'});
xlim([0 0.9])
