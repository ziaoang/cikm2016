x = [1 2 3];
y = [
    0.5389 0.5278 0.5389;
    0.4889 0.5028 0.5167;
    0.3880 0.4000 0.4139
    ];
h=bar(x,y,'grouped');
legend('SimpleKL', 'QEFEM-ML', 'QEFEM-Filtering', 'location','northeast');
xlabel('K');
ylabel('P@K');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xticklabel',{ '5', '10', '30'});
%set(gca,'ytick',[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]);
%set(gca,'yticklabel',{ '0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'});
ylim([0.35 0.65])
set(gca, 'ytick',0.35:0.05:0.65)
% show grid
grid on;

% change bar color
%set(h(1),'FaceColor','r');
%set(h(2),'FaceColor','g');
%set(h(3),'FaceColor','b');