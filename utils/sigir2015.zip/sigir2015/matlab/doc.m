eta = [30 50 100 300 500];
%qe p30
p10 =            [ 
0.5111
0.5167
0.5139
0.5111
0.5139
 ];
p10_baseline =   [0.4889 0.4889 0.4889 0.4889 0.4889];
p10_2s = [0.5556
0.5556
0.55
0.5528
0.5556
];

p30 = [
0.412
0.4139
0.412
0.4111
0.4111
  ];
p30_2s = [0.4426
0.4426
0.437
0.4398
0.4407
];
p30_baseline =   [0.3880 0.3880 0.3880 0.3880 0.3880];

map =            [ 0.4086
0.4112
0.4086
0.4057
0.4036
 ];
map_2s = [0.4126
0.4127
0.408
0.4086
0.4101
];
map_baseline =   [0.3865 0.3865 0.3865 0.3865 0.3865];


figure(1);
plot(eta, p10_2s, 'g-^', eta,p10,'r-o',  eta,p10_baseline,'b-.');
legend('QEFEM + SMM',  'QEFEM', 'SimpleKL', 'location','northeast');
xlabel('# of feedback tweets');
ylabel('P@10');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])
ylim([0.48,0.6])



figure(2);
plot(eta, p30_2s, 'g-^', eta,p30,'r-o',  eta, p30_baseline,'b-.');
legend('QEFEM + SMM',  'QEFEM', 'SimpleKL', 'location','northeast');
xlabel('# of feedback tweets');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])
ylim([0.385 0.465])


figure(3);
plot(eta, map_2s, 'g-^', eta,map,'r-o',  eta, map_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM',  'SimpleKL', 'location','northeast');
xlabel('# of feedback tweets');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 14);
set(gca,'xtick',[30 50 100 300 500]);
set(gca,'xticklabel',{ '30', '50', '100', '300', '500'});
xlim([30 500])

