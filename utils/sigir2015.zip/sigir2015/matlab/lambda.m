eta = [0.1 0.3 0.5 0.7 0.9 1.0];
%qe p30
p10 =            [ 
0.5111
0.5167
0.5139
0.5167
0.5139
0.4889
 ];
p10_baseline =   [0.4889 0.4889 0.4889 0.4889 0.4889 0.4889];
p5_smm = [0.5667 0.5667 0.5667 0.5667 0.5667 0.5667];
p10_2s = [0.5444
0.5556
0.5556
0.5556
0.5556
0.5528
];

p30 = [
0.4176
0.4157
0.4148
0.4139
0.4139
0.388
  ];
p30_baseline =   [0.3880 0.3880 0.3880 0.3880 0.3880 0.3880];
p30_smm = [0.4269 0.4269 0.4269 0.4269 0.4269 0.4269];
p30_2s = [0.4296
0.4398
0.4426
0.4435
0.4426
0.4426
];

map =            [ 
0.4034
0.4076
0.4092
0.4112
0.4104
0.3854
 ];
map_baseline = [0.3865 0.3865 0.3865 0.3865 0.3865 0.3865];
map_smm = [0.4082 0.4082 0.4082 0.4082 0.4082 0.4082];
map_2s = [0.4101
0.4106
0.412
0.4127
0.4141
0.4128
];


figure(1);
plot( eta, p10_2s, 'g-^',  eta,p10,'r-o', eta,p10_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM',  'SimpleKL', 'location','northwest');
xlabel('\lambda_E');
ylabel('P@10');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0.1 0.3  0.5  0.7  0.9 1]);
set(gca,'xticklabel',{ '0.1','0.3','0.5','0.7','0.9','1'});
xlim([0.1 1])
ylim([0.48 0.6])


figure(2);
plot(eta, p30_2s, 'g-^',  eta,p30,'r-o', eta, p30_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM',  'SimpleKL', 'location','northwest');
xlabel('\lambda_E');
ylabel('P@30');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0.1 0.3  0.5  0.7  0.9 1]);
set(gca,'xticklabel',{ '0.1','0.3','0.5','0.7','0.9','1'});
xlim([0.1 1])
ylim([0.38 0.48])

figure(3);
plot(eta, map_2s, 'g-^',  eta,map,'r-o', eta, map_baseline,'b-.');
legend('QEFEM + SMM', 'QEFEM','SimpleKL', 'location','northwest');
xlabel('\lambda_E');
ylabel('MAP');
set(get(gca,'XLabel'),'FontSize',16,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',16,'Vertical','bottom');
set(gca, 'Fontname', 'Times New Roman', 'Fontsize', 16);
set(gca,'xtick',[0.1 0.3  0.5  0.7  0.9 1]);
set(gca,'xticklabel',{'0.1','0.3','0.5','0.7','0.9','1'});
xlim([0.1 1])
ylim([0.38 0.43])
